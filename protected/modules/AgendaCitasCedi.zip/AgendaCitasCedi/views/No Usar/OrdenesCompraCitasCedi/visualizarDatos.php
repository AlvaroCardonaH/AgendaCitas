

<?php echo Yii::app()->user->id ?>

<?php echo $elUsuarioAdmin->EmailUsuario ; ?><br />
<?php echo $elUsuarioAdmin->NombreCompleto ; ?> <br />

<?php echo $elUsuario->EmailUsuario ; ?> <br />
<?php echo $elUsuario->NombreCompleto ; ?><br />
